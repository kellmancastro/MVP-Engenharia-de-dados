# MVP Engenharia de Dados: Avaliação x Recompra no E-commerce Olist

Pipeline de dados na nuvem (Databricks Free Edition, arquitetura medalhão) para medir **como a nota da última compra influencia a chance de o cliente comprar novamente**.

> ⚠️ **Antes de entregar:** substitua todos os trechos marcados com `[PREENCHER]` e `[PRINT]` pelos seus resultados e screenshots (salve as imagens na pasta `imagens/`).

**Estrutura do repositório**

```
notebooks/
  01_bronze_ingestao.py       -> ingestão dos CSVs (Bronze)
  02_qualidade_dados.py       -> diagnóstico de qualidade
  03_silver_transformacao.py  -> limpeza e padronização (Silver)
  04_gold_modelagem.py        -> modelo estrela e métricas (Gold)
  05_analise.sql              -> respostas às perguntas
imagens/                      -> screenshots usados neste README
```

---

## 1. Contexto de Negócio e Perguntas (Etapa 2 e 4.1)

### Problema

Em e-commerce, conquistar um cliente novo custa bem mais do que manter um cliente atual. A avaliação que o cliente dá após a entrega é um dos poucos sinais diretos de satisfação disponíveis. O problema deste MVP é entender **se a nota dada no último pedido ajuda a prever se o cliente voltará a comprar**, o que permitiria à empresa agir (cupom, contato do SAC) logo após uma avaliação ruim.

### Perguntas de negócio

1. Qual é a taxa geral de recompra dos clientes da Olist?
2. **Quando a avaliação da última compra é boa (4-5), neutra (3) ou ruim (1-2), qual é a probabilidade de o cliente comprar de novo?** (pergunta principal)
3. Como a taxa de recompra varia em cada nota, de 1 a 5?
4. O resultado se mantém quando olhamos apenas a primeira compra de cada cliente?
5. Entregas atrasadas geram notas piores e menos recompra?
6. Entre os clientes que recompraram, a nota altera o tempo até a nova compra?

### Definição de "recompra"

Para cada pedido entregue (o *pedido de referência*), verifica-se se o **mesmo cliente** (`customer_unique_id`) fez um novo pedido **em uma data posterior, em até 180 dias**. Dessa forma, a nota do pedido de referência é sempre a nota da **última compra realizada até aquele momento**. Pedidos no mesmo dia não contam como recompra. Só entram no cálculo pedidos com pelo menos 180 dias de observação até o fim do dataset, para não subestimar a recompra de pedidos recentes.

### Fonte e licença dos dados

- **Dataset:** Brazilian E-Commerce Public Dataset by Olist, disponível no Kaggle: https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce
- **Conteúdo:** cerca de 100 mil pedidos reais e anonimizados feitos entre 2016 e 2018 em diversos marketplaces brasileiros.
- **Licença:** CC BY-NC-SA 4.0 (uso permitido para fins não comerciais, com atribuição e compartilhamento pela mesma licença). O uso acadêmico deste trabalho está de acordo com a licença.

### Estrutura dos dados brutos utilizados

| Arquivo | Linhas (aprox.) | Colunas principais |
|---|---|---|
| olist_customers_dataset.csv | 99 mil | customer_id, customer_unique_id, customer_zip_code_prefix, customer_city, customer_state |
| olist_orders_dataset.csv | 99 mil | order_id, customer_id, order_status, order_purchase_timestamp, order_approved_at, order_delivered_carrier_date, order_delivered_customer_date, order_estimated_delivery_date |
| olist_order_reviews_dataset.csv | 99 mil | review_id, order_id, review_score, review_comment_title, review_comment_message, review_creation_date, review_answer_timestamp |
| olist_order_items_dataset.csv | 112 mil | order_id, order_item_id, product_id, seller_id, shipping_limit_date, price, freight_value |

Os demais arquivos do dataset (produtos, vendedores, pagamentos, geolocalização) não foram usados porque não são necessários para as perguntas definidas, seguindo a ideia de MVP.

---

## 2. Carga dos Dados (Etapa 4.2)

1. Download manual dos 4 CSVs no Kaggle.
2. O notebook [`01_bronze_ingestao.py`](notebooks/01_bronze_ingestao.py) cria os schemas `workspace.bronze`, `workspace.silver`, `workspace.gold` e o volume `workspace.bronze.raw_files`.
3. Upload dos CSVs para o volume pela interface do Unity Catalog (Catalog > bronze > Volumes > raw_files > Upload).
4. O mesmo notebook lê cada CSV com PySpark (todas as colunas como texto, com `multiLine` e `escape` para tratar comentários com quebra de linha e aspas) e grava como tabela Delta na camada Bronze, adicionando `_ingestion_ts` e `_source_file` para rastreabilidade.

`[PRINT]` volume com os 4 arquivos enviados
`[PRINT]` resultado da célula de carga com a contagem de linhas de cada tabela

---

## 3. Modelagem e Catálogo de Dados (Etapa 4.3)

### Arquitetura

```mermaid
flowchart LR
  K[Kaggle CSVs] --> V[Volume raw_files]
  V --> B[(Bronze<br/>customers, orders,<br/>order_reviews, order_items)]
  B --> S[(Silver<br/>clientes, pedidos,<br/>avaliacoes, itens_pedido)]
  S --> G[(Gold<br/>fato_pedido, dim_cliente,<br/>dim_data, agg_recompra_por_nota)]
  G --> A[Análise SQL]
```

### Modelo estrela (camada Gold)

```mermaid
erDiagram
  DIM_CLIENTE ||--o{ FATO_PEDIDO : "customer_unique_id"
  DIM_DATA ||--o{ FATO_PEDIDO : "data_compra"
  FATO_PEDIDO {
    string order_id PK
    string customer_unique_id FK
    date data_compra FK
    int nota
    string faixa_nota
    boolean entregue_com_atraso
    int seq_pedido_cliente
    boolean recompra_180d
    boolean elegivel_janela_180d
  }
  DIM_CLIENTE {
    string customer_unique_id PK
    string uf
    int qtd_pedidos
    boolean cliente_recorrente
  }
  DIM_DATA {
    date data PK
    int ano
    int mes
  }
```

A granularidade da fato é **1 linha por pedido entregue**, pois a pergunta relaciona a nota de um pedido com o que acontece depois dele. A dimensão de cliente usa `customer_unique_id` (e não `customer_id`) porque é a única chave que identifica a mesma pessoa em pedidos diferentes.

### Catálogo de dados

Todas as descrições abaixo também estão gravadas no **Unity Catalog** (comentários de tabela e coluna), aplicados pela função `documentar()` dos notebooks 03 e 04.

`[PRINT]` Catalog Explorer mostrando a tabela gold.fato_pedido com as descrições das colunas
`[PRINT]` aba Lineage da tabela gold.fato_pedido

#### gold.fato_pedido
Pedidos entregues com nota e indicadores de recompra. Linhagem: silver.pedidos + silver.clientes + silver.avaliacoes + silver.itens_pedido.

| Coluna | Tipo | Descrição | Domínio | Linhagem |
|---|---|---|---|---|
| order_id | string | Identificador do pedido | hash único | silver.pedidos |
| customer_unique_id | string | Identificador da pessoa | hash | silver.clientes (JOIN por customer_id) |
| dt_compra | timestamp | Data e hora da compra | 2016 a 2018 | silver.pedidos |
| data_compra | date | Data da compra (chave de dim_data) | 2016 a 2018 | derivado de dt_compra |
| nota | int | Nota da avaliação | 1 a 5 ou nulo | silver.avaliacoes |
| faixa_nota | string | Categoria da nota | Boa (4-5), Neutra (3), Ruim (1-2), nulo | derivado de nota |
| tem_comentario | boolean | Cliente escreveu comentário | true/false | silver.avaliacoes |
| qtd_itens | bigint | Itens no pedido | ≥ 1 | agregado de silver.itens_pedido |
| valor_produtos | decimal | Soma dos preços (R$) | > 0 | agregado de silver.itens_pedido |
| valor_frete | decimal | Soma do frete (R$) | ≥ 0 | agregado de silver.itens_pedido |
| dias_entrega | int | Dias entre compra e entrega | ≥ 0 | derivado de silver.pedidos |
| entregue_com_atraso | boolean | Entregue após a data prometida | true/false | derivado de silver.pedidos |
| seq_pedido_cliente | int | Ordem do pedido na história do cliente | ≥ 1 | função de janela |
| data_proxima_compra | date | Próxima compra em dia posterior | data ou nulo | função de janela |
| dias_ate_proxima_compra | int | Dias até a próxima compra | ≥ 1 ou nulo | derivado |
| teve_recompra | boolean | Comprou de novo em qualquer momento | true/false | derivado |
| recompra_180d | boolean | Comprou de novo em até 180 dias | true/false | derivado |
| elegivel_janela_180d | boolean | Pedido tem 180 dias de observação | true/false | derivado |

#### gold.dim_cliente
Uma linha por pessoa. Linhagem: gold.fato_pedido + silver.clientes.

| Coluna | Tipo | Descrição | Domínio |
|---|---|---|---|
| customer_unique_id | string | Chave da pessoa | hash único |
| cidade | string | Cidade do pedido mais recente | texto minúsculo |
| uf | string | UF do pedido mais recente | 27 siglas |
| qtd_pedidos | bigint | Total de pedidos entregues | ≥ 1 |
| qtd_dias_com_compra | bigint | Dias distintos com compra | ≥ 1 |
| cliente_recorrente | boolean | Comprou em mais de um dia | true/false |
| data_primeira_compra | date | Primeira compra | 2016 a 2018 |
| data_ultima_compra | date | Última compra | 2016 a 2018 |
| nota_primeiro_pedido | int | Nota do primeiro pedido | 1 a 5 ou nulo |
| nota_ultimo_pedido | int | Nota do último pedido | 1 a 5 ou nulo |

#### gold.dim_data
Calendário diário gerado entre a menor e a maior data de compra: `data` (date), `ano` (2016 a 2018), `trimestre` (1 a 4), `mes` (1 a 12), `ano_mes` (yyyy-MM), `dia_semana` (1 = domingo a 7 = sábado), `fim_de_semana` (boolean).

#### gold.agg_recompra_por_nota
Métrica pré-calculada a partir de gold.fato_pedido (somente pedidos elegíveis e avaliados): `nota` (1 a 5), `faixa_nota`, `pedidos_referencia`, `pedidos_com_recompra`, `pct_recompra_180d` (0 a 100).

#### Camada Silver (resumo)

| Tabela | Granularidade | Origem | Colunas |
|---|---|---|---|
| silver.clientes | 1 por customer_id | bronze.customers | customer_id, customer_unique_id, cep_prefixo, cidade, uf |
| silver.pedidos | 1 por order_id | bronze.orders | order_id, customer_id, status, dt_compra, dt_aprovacao, dt_envio_transportadora, dt_entrega, dt_entrega_estimada |
| silver.avaliacoes | 1 por order_id | bronze.order_reviews | review_id, order_id, nota, titulo_comentario, comentario, tem_comentario, dt_envio_pesquisa, dt_resposta |
| silver.itens_pedido | 1 por (order_id, item_seq) | bronze.order_items | order_id, item_seq, product_id, seller_id, preco, frete |

---

## 4. Pipeline de Dados (Etapa 4.4)

O pipeline foi dividido em **um notebook por etapa**, executados em sequência (01 → 05). Todos os scripts estão neste repositório, sincronizado com o Databricks via Git folder (Databricks Repos).

| Notebook | Entrada | Saída | O que faz e por quê |
|---|---|---|---|
| 01_bronze_ingestao | CSVs no volume | 4 tabelas bronze | Grava o dado exatamente como chegou, apenas com metadados de carga, para preservar rastreabilidade |
| 02_qualidade_dados | tabelas bronze | relatórios | Mede nulos, duplicatas, domínios, datas e outliers para decidir as regras da Silver |
| 03_silver_transformacao | tabelas bronze | 4 tabelas silver | Tipagem com TRY_CAST, padronização de texto, deduplicação com QUALIFY/ROW_NUMBER e filtro de valores inválidos |
| 04_gold_modelagem | tabelas silver | fato, 2 dimensões e 1 agregado | JOIN de pedidos com clientes para obter o customer_unique_id, JOIN com avaliações para trazer a nota, agregação dos itens por pedido e funções de janela para identificar a próxima compra de cada cliente |
| 05_analise | tabelas gold | respostas | Consultas SQL para cada pergunta de negócio |

Principais transformações documentadas:

- **JOIN pedidos × clientes por `customer_id`** para trazer o `customer_unique_id`, sem o qual não é possível identificar recompra.
- **JOIN pedidos × avaliações por `order_id`** para associar cada compra à sua nota.
- **Agregação de itens por `order_id`** para obter valor e quantidade de itens do pedido.
- **Função de janela `MIN(data_compra) OVER (... RANGE BETWEEN 1 FOLLOWING ...)`** para encontrar a próxima compra do cliente em uma data posterior.
- **Filtro `status = 'delivered'`** na fato, pois só pedidos entregues podem ser avaliados de forma justa.

`[PRINT]` Catalog Explorer mostrando os schemas bronze, silver e gold com suas tabelas
`[PRINT]` Git folder conectado ao repositório no Databricks

---

## 5. Qualidade de Dados (Etapa 4.5)

Diagnóstico feito no notebook `02_qualidade_dados` e validado ao final do `03_silver_transformacao`.

| Verificação | Problema encontrado | Tratamento |
|---|---|---|
| Completude | `[PREENCHER]` % de avaliações sem comentário; datas de aprovação/entrega nulas em pedidos não entregues | Comentários vazios viraram nulo e flag `tem_comentario`; datas nulas mantidas (são esperadas) e fato usa apenas pedidos entregues |
| Unicidade | `[PREENCHER]` pedidos com mais de uma avaliação; `review_id` repetido | Mantida apenas a avaliação mais recente de cada pedido |
| Consistência de chave | `[PREENCHER]` customer_id para `[PREENCHER]` customer_unique_id | Toda análise de recompra usa `customer_unique_id` |
| Domínio | Status em 8 categorias; notas `[PREENCHER]` fora de 1 a 5 | Status padronizado em minúsculas; notas inválidas descartadas |
| Acurácia de datas | `[PREENCHER]` pedidos entregues sem data de entrega | Atraso fica nulo nesses casos e é excluído da P5 |
| Integridade | `[PREENCHER]` pedidos sem avaliação | Mantidos na fato com nota nula e excluídos das métricas por nota |
| Outliers | Preço máximo de `[PREENCHER]` contra mediana de `[PREENCHER]` | Mantidos (vendas reais de itens caros) e sem impacto na métrica de recompra, que não usa preço |
| Tipagem | Todas as colunas chegam como texto | TRY_CAST para timestamp, int e decimal |
| Censura temporal | Pedidos recentes não tiveram tempo de gerar recompra | Janela de observação de 180 dias (`elegivel_janela_180d`) |

`[PRINT]` tabela de nulos por coluna
`[PRINT]` consulta de duplicatas
`[PRINT]` validação pós-Silver com zeros

---

## 6. Análise de Dados (Etapa 4.5)

Consultas no notebook [`05_analise.sql`](notebooks/05_analise.sql).

**P1. Taxa geral de recompra:** `[PREENCHER]` % dos clientes compraram em mais de um dia.
`[PRINT]`

**P2. Recompra em 180 dias por faixa da última nota (pergunta principal):**

| Faixa da nota | Pedidos de referência | % recompra | IC 95% |
|---|---|---|---|
| Boa (4-5) | `[PREENCHER]` | `[PREENCHER]` | `[PREENCHER]` |
| Neutra (3) | `[PREENCHER]` | `[PREENCHER]` | `[PREENCHER]` |
| Ruim (1-2) | `[PREENCHER]` | `[PREENCHER]` | `[PREENCHER]` |

`[PRINT]` tabela e gráfico de barras

Interpretação: `[PREENCHER]` Exemplo de escrita: "Clientes cuja última compra recebeu nota boa recompraram em X% dos casos, contra Y% quando a nota foi ruim, ou seja, uma chance Z vezes maior. Como os intervalos de confiança não se sobrepõem, a diferença não parece ser acaso."

**P3. Recompra por nota de 1 a 5:** `[PREENCHER]` a taxa cresce/não cresce de forma consistente com a nota?
`[PRINT]`

**P4. Apenas a primeira compra:** `[PREENCHER]` o padrão da P2 se repete?
`[PRINT]`

**P5. Atraso na entrega:** pedidos atrasados têm nota média de `[PREENCHER]` contra `[PREENCHER]` no prazo, e recompra de `[PREENCHER]` contra `[PREENCHER]`.
`[PRINT]`

**P6. Tempo até a recompra:** mediana de `[PREENCHER]` dias para nota boa contra `[PREENCHER]` para nota ruim.
`[PRINT]`

### Discussão geral

`[PREENCHER]` Pontos a abordar:

- A recompra no Olist é baixa no geral, o que é esperado por ser um marketplace de compras esporádicas e sem programa de fidelidade. Isso limita o tamanho absoluto das diferenças.
- Compare a diferença relativa entre nota boa e ruim (quantas vezes maior) e não só os pontos percentuais.
- Relacione com a P5: se o atraso derruba a nota, a logística é uma alavanca indireta de recompra.
- Correlação não é causalidade: a nota pode refletir outros fatores (tipo de produto, região, preço) que também afetam a recompra.
- Recomendação de negócio: acionar clientes logo após notas 1-2 (contato do SAC, cupom) e medir o efeito em um teste A/B.

---

## 7. Autoavaliação

`[PREENCHER com sua experiência real]` Roteiro sugerido:

- **Objetivos atingidos:** quais perguntas foram respondidas e com que confiança.
- **Dificuldades:** por exemplo, perceber que `customer_id` muda a cada pedido, tratar comentários com quebra de linha no CSV, definir uma regra justa de recompra considerando pedidos recentes, configurar o Databricks Free Edition.
- **Limitações:** recompra muito baixa no dataset; a avaliação às vezes é respondida depois da compra seguinte; período curto (2016 a 2018); dados de um único marketplace.
- **Trabalhos futuros:** incluir categoria de produto e pagamentos, análise de sentimento dos comentários, modelo preditivo de recompra, orquestração com Databricks Jobs, carga incremental.
